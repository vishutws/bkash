var config = {
    paths: {
		thBkash: 'Thinktrek_Bkash/js/bkash-checkout-sandbox',
        thbkashcustom: 'Thinktrek_Bkash/js/bkashcustom'
        
    }
};
