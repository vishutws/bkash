<?php
/**
 * Copyright © Thinktrek. All rights reserved.
 * See LICENSE.txt for license details.
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Thinktrek_Bkash',
    __DIR__
);
